#!/usr/bin/env python3
"""turn2.py BASE MODEL [--tokens 128000] [--pressure 0] [--pressure-tokens 32768] [--reply 16]
             [--seed 20261123] [--output FILE]

The resume cell: a kept conversation, its second turn, and the resumed-vs-fresh token check on one boot.

  A1   the conversation's first prompt P, fresh (a UUID salt in its first line), --reply tokens kept as R1
  F*   --pressure fresh-salted fillers of --pressure-tokens tokens (optional store pressure)
  A2   P again: the resume. cached_tokens must be > 0 and the reply text sha must equal A1's
  T2   turn 2: [user P, assistant R1, user Q]. cached_tokens must cover P + R1, and its ttft is the
       turn-2 resume latency (a cold turn 2 would prefill all of P + R1 + Q)
  A3   P again after turn 2: cached_tokens > 0 and the same text sha as A1 (the conversation survived)

PASS only when every request completes, A2/A3/T2 are cached, and A1/A2/A3 carry one text sha. The sha is over
the assembled content because this engine's stream stats carry no token hash. Greedy, thinking off.
"""
import argparse
import hashlib
import json
import sys
import time
import urllib.request
import uuid
from random import Random

WORDS = ("lattice probe ferrule datum spindle gauge trellis offset stylus kinematic fixture wafer cosine baseline "
         "granite bearing encoder servo axis spline tolerance flatness runout").split()
QUESTION = "Reply with the single word: done."


def filler(tokens, rnd):
    lines = max(1, int(tokens / 21.8))
    out = [f"Record {uuid.uuid4().hex[:8]} of the number set."]
    for i in range(lines):
        out.append(f"{i + 1}. " + " ".join(rnd.choice(WORDS) for _ in range(12)))
    return "\n".join(out)


def stream(base, model, messages, tokens):
    body = {
        "model": model,
        "max_tokens": tokens,
        "temperature": 0,
        "stream": True,
        "stream_options": {"include_usage": True},
        "chat_template_kwargs": {"enable_thinking": False},
        "messages": messages,
    }
    req = urllib.request.Request(base + "/v1/chat/completions", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    t0 = time.perf_counter()
    first = None
    texts = []
    usage = {}
    errors = []
    with urllib.request.urlopen(req, timeout=3600) as resp:
        for raw in resp:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                # SSE framing is not an error: `: keepalive` comments are what the engine sends while a long
                # prefill is silent (server/sse.zig:26-27), and event/id/retry fields are the format's own.
                if line and not line.startswith((":", "event:", "id:", "retry:")):
                    errors.append(line[:200])
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                obj = json.loads(data)
            except ValueError:
                errors.append(data[:200])
                continue
            if obj.get("error"):
                errors.append(json.dumps(obj["error"])[:300])
            if obj.get("usage"):
                usage = obj["usage"]
            for choice in obj.get("choices") or []:
                delta = choice.get("delta") or {}
                text = delta.get("content") or delta.get("reasoning_content") or ""
                if text:
                    if first is None:
                        first = time.perf_counter()
                    texts.append(text)
    end = time.perf_counter()
    content = "".join(texts)
    return {
        "prompt_tokens": usage.get("prompt_tokens"),
        "cached_tokens": (usage.get("prompt_tokens_details") or {}).get("cached_tokens"),
        "completion_tokens": usage.get("completion_tokens"),
        "ttft_s": (first - t0) if first is not None else None,
        "elapsed_s": end - t0,
        "text": content,
        "chars": len(content),
        "text_sha256": hashlib.sha256(content.encode("utf-8")).hexdigest(),
        "errors": errors,
    }


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("base")
    p.add_argument("model")
    p.add_argument("--tokens", type=int, default=128000)
    p.add_argument("--pressure", type=int, default=0, help="fresh fillers between A1 and A2")
    p.add_argument("--pressure-tokens", type=int, default=32768)
    p.add_argument("--reply", type=int, default=16)
    p.add_argument("--seed", type=int, default=20261123)
    p.add_argument("--output")
    a = p.parse_args(argv)
    rnd = Random(a.seed)
    base = a.base.rstrip("/")
    conv = filler(a.tokens, rnd)
    rows = []

    def send(label, messages):
        r = stream(base, a.model, messages, a.reply)
        r["label"] = label
        rows.append(r)
        print(f"{label} prompt {r['prompt_tokens']} cached {r['cached_tokens']} tokens {r['completion_tokens']} "
              f"ttft {r['ttft_s']:.3f} elapsed {r['elapsed_s']:.3f} chars {r['chars']} "
              f"sha {r['text_sha256'][:16]} errors {len(r['errors'])}", flush=True)
        return r

    a1 = send("A1", [{"role": "user", "content": conv}])
    for i in range(a.pressure):
        send(f"F{i + 1}", [{"role": "user", "content": filler(a.pressure_tokens, rnd)}])
    a2 = send("A2", [{"role": "user", "content": conv}])
    t2_messages = [
        {"role": "user", "content": conv},
        {"role": "assistant", "content": a1["text"]},
        {"role": "user", "content": QUESTION},
    ]
    t2 = send("T2", t2_messages)
    a3 = send("A3", [{"role": "user", "content": conv}])

    by = {r["label"]: r for r in rows}
    complete = all((r["completion_tokens"] or 0) > 0 and r["chars"] > 0 and not r["errors"] for r in rows)
    # The core resume: the conversation's next asks (A2, and T2 past P + R1) hit the cache. A3's survival is a
    # separate cache-capacity result, not part of the resume check: with one 129k state's ~2.3 GiB in a 3.1 GiB
    # store, the appended turn's own state displaces the base conversation, so A3 re-prefills (measured).
    resumed = (by["A2"]["cached_tokens"] or 0) > 0 and (by["T2"]["cached_tokens"] or 0) > 0
    survived = (by["A3"]["cached_tokens"] or 0) > 0
    same = a1["text_sha256"] == a2["text_sha256"] == a3["text_sha256"]
    t2_prefix = None
    if t2["cached_tokens"] is not None and a1["prompt_tokens"] is not None and a1["completion_tokens"] is not None:
        t2_prefix = t2["cached_tokens"] - a1["prompt_tokens"]
    verdict = "PASS" if (complete and resumed and same) else "FAIL"
    print(f"TURN2 complete {complete} resumed {resumed} same_text {same} "
          f"turn2_cached {t2['cached_tokens']} turn2_cached_beyond_prompt {t2_prefix} "
          f"sha A1 {a1['text_sha256'][:16]} A2 {a2['text_sha256'][:16]} A3 {a3['text_sha256'][:16]} verdict {verdict}")
    print(f"TURN2-SURVIVAL A3_cached {a3['cached_tokens']} survived {survived}")
    if a.output:
        with open(a.output, "w", encoding="utf-8") as fh:
            json.dump({"tokens": a.tokens, "pressure": a.pressure, "pressure_tokens": a.pressure_tokens,
                       "reply": a.reply, "rows": [{k: v for k, v in r.items() if k != "text"} for r in rows],
                       "complete": complete, "resumed": resumed, "survived": survived, "same_text": same,
                       "turn2_cached_beyond_prompt": t2_prefix, "verdict": verdict}, fh, indent=2)
            fh.write("\n")
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
