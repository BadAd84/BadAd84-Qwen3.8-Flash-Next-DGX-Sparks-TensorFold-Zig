#!/usr/bin/env bash
# driver.sh [window] - DevBootComp: the r5-dev composition's image build and dev-arm boot on spark6, in ONE hold of
# ~/work/gpu.lock. Inside the hold: production is stopped and its memory recorded; a pristine TensorFold at 1ece6e6d
# is fetched and the composition's 40 patches applied and manifest-checked (dd655181...); the recipe's own
# build_patches.sh builds tensorfold-qwen38:r5dev40 from a local bare repo of that pristine tree; the composition's
# int4-contract suite runs on the built tree with the box nvcc; the image boots through the dev launcher with
# dev.env sourced; the window self-check, exactness set, /stats-or-its-gate, the tier's budget and one 129k resume are
# recorded; production is restored by the EXIT trap with the pinned image and check-prod-env must read 0 problems.
#
#   bash driver.sh window                 queue on ~/work/gpu.lock, then run
#   DB_LOCKED=1 bash driver.sh window     run now (the caller holds the lock)
set -u
SELF=$(readlink -f "$0")
BOX=${DB_BOX:-$HOME/work/DevBootComp}
OUT=$BOX/out
IN=$BOX/in
PKG=$BOX/pkg
TOOLS=$BOX/tools
RECIPE=${DB_RECIPE:-$HOME/qwen-zig}
DEV=$IN/dev.env
IMG=tensorfold-qwen38:r5dev40
CUDA_IMG=tensorfold-qwen38:zig-db28187
BASE_REF=1ece6e6dbbc073582d50738ce8e73e3c3261a73b
WANT_MANIFEST=dd655181afd5494ea78711c96f2240a5bf1d787cbcea207c17f971f2c6d31d19
PROD_IMAGE=tensorfold-qwen38:zmerge8-kfix-e5139fcd8c6101c7
PROD_ID=sha256:235211ea77ee4ed0e61c4c2e73746ed17eccfb6b9e7571eb0787802440f8a33f
CN=qwen38-flash-next-tf
URL=http://127.0.0.1:8888
LOCKF=${DB_LOCKF:-$HOME/work/gpu.lock}
BASE=$BOX/base
TREE=$BOX/tree
NEWSRC=$BOX/newsrc
SRV=$BOX/srv
ZC=$BOX/zcache
mkdir -p "$OUT" "$OUT/marks" "$ZC"

log() { echo "$(date -Is) $*" >> "$OUT/run.log"; }
mark() { : > "$OUT/marks/$1"; log "MARK $1"; }
now() { date -Is; }
memav() { awk '/MemAvailable/{print int($2/1048576)}' /proc/meminfo; }
freegib() { df --output=avail -BG "$HOME" | tail -1 | tr -dc '0-9'; }
healthcode() { curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$1/health" 2>/dev/null; }
imgof() { docker inspect "$CN" --format '{{.Config.Image}} {{.Image}}' 2>/dev/null || true; }
gputemp() { nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader 2>/dev/null | tr -d ' '; }
gpu() { nvidia-smi --query-gpu=temperature.gpu,clocks.sm,power.draw --format=csv,noheader 2>/dev/null | tr -d ' '; }
startlock_free() { flock -n "$HOME/.local/state/qwen38-flash-next-tf/start.lock" true 2>/dev/null; }
tree_manifest() { ( cd "$1" && find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum ) | sha256sum | cut -d' ' -f1; }
tree_files() { ( cd "$1" && find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum ) | wc -l; }

RESTORED=0
STOPPED_PROD=0
TOUCHED=0
IMAGE_ID=""

restore() {
  local i code=000 pimg="" rc=0
  if [ "$RESTORED" = 1 ]; then return 0; fi
  RESTORED=1
  log "RESTORE begin $(now) stopped_prod=$STOPPED_PROD"
  pkill -f "git daemon.*--port=9419" > /dev/null 2>&1 || true
  ( cd "$RECIPE" && ./stop.sh ) >> "$OUT/run.log" 2>&1 || true
  for i in $(seq 1 60); do
    [ "$(docker inspect -f '{{.State.Running}}' "$CN" 2>/dev/null)" != true ] && break
    sleep 2
  done
  for i in $(seq 1 60); do startlock_free && break; sleep 2; done
  if ! startlock_free; then
    echo "start.lock is held by another ./start.sh: the production launcher was not run" > "$OUT/prod.out"
    log "PROD-START-LOCKED: start.lock is held; production was not started"
  else
    ( env -u IMAGE LOCK_HOLDER=0 IMAGE="$PROD_IMAGE" "$HOME/qwen6-start-prod.sh" </dev/null ) > "$OUT/prod.out" 2>&1 || rc=$?
  fi
  for i in $(seq 1 180); do code=$(healthcode "$URL"); [ "$code" = 200 ] && break; sleep 5; done
  pimg=$(imgof)
  log "RESTORE prod_rc $rc /health $code image ${pimg:-absent} $(now)"
  echo "prod /health $code (start rc $rc) image ${pimg:-absent} $(now)" > "$OUT/RESTORED"
  curl -s --max-time 10 "$URL/health" > "$OUT/health-restored.json" 2>/dev/null || true
  docker ps --format '{{.Names}} {{.Image}} {{.Status}}' > "$OUT/restored-container.txt" 2>/dev/null || true
  if [ "$code" = 200 ]; then mark RESTORED; else log "PROD-HEALTH-BAD /health ${code}"; fi
  case "$pimg" in
    *"$PROD_IMAGE"*"$PROD_ID"*) mark PROD-IMAGE-OK; log "PROD-IMAGE-OK $pimg" ;;
    *) log "PROD-IMAGE-BAD: \"${pimg:-absent}\" does not carry $PROD_IMAGE $PROD_ID" ;;
  esac
  docker inspect "$CN" > "$OUT/prod-inspect-after.json" 2>/dev/null || true
  python3 "$TOOLS/check-prod-env.py" --prod "$TOOLS/prod.env" --inspect "$OUT/prod-inspect-after.json" \
    > "$OUT/prod-env-after.txt" 2>&1 || true
  log "PROD-ENV after: $(tr '\n' ' ' < "$OUT/prod-env-after.txt" 2>/dev/null | cut -c1-400)"
  if grep -q '0 problem(s)$' "$OUT/prod-env-after.txt" 2>/dev/null; then
    mark PROD-ENV-EQUAL; log "PROD-ENV-EQUAL $(tail -1 "$OUT/prod-env-after.txt")"
  else
    log "PROD-ENV-BAD $(tr '\n' ' ' < "$OUT/prod-env-after.txt" 2>/dev/null | cut -c1-400)"
  fi
  if [ -s "$OUT/prod-env-before.txt" ] && [ -s "$OUT/prod-env-after.txt" ]; then
    if diff -q "$OUT/prod-env-before.txt" "$OUT/prod-env-after.txt" > /dev/null 2>&1; then
      echo "prod-env before and after: identical ($(tail -1 "$OUT/prod-env-after.txt"))" > "$OUT/prod-env-drift.txt"
      log "PROD-ENV-DRIFT $(cat "$OUT/prod-env-drift.txt")"
    else
      diff -u "$OUT/prod-env-before.txt" "$OUT/prod-env-after.txt" > "$OUT/prod-env-drift.txt" 2>&1
      log "PROD-ENV-DRIFT $(head -20 "$OUT/prod-env-drift.txt" | tr '\n' ' ' | cut -c1-400)"
    fi
  fi
  log "RESTORE end $(now)"
}

on_exit() {
  local rc=$?
  log "EXIT rc $rc $(now) touched=$TOUCHED"
  if [ "$TOUCHED" = 1 ]; then restore; fi
  log "EXIT-DONE $(now)"
  exit $rc
}
trap on_exit EXIT
trap 'exit 143' INT TERM

if [ "${DB_LOCKED:-0}" != 1 ]; then
  echo "QUEUED $(now) pid $$" >> "$OUT/run.log"
  exec flock -o -w 43200 "$LOCKF" env DB_LOCKED=1 DB_BOX="$BOX" bash "$SELF" window
fi

stop_cn() {
  local i
  ( cd "$RECIPE" && ./stop.sh ) >> "$OUT/run.log" 2>&1 || true
  for i in $(seq 1 30); do
    [ "$(docker inspect -f '{{.State.Running}}' "$CN" 2>/dev/null)" != true ] && break
    sleep 2
  done
}

preflight() {
  local id c load n
  [ -f "$DEV" ] || { log "PREFLIGHT-ABORT no $DEV"; return 9; }
  [ -d "$PKG" ] || { log "PREFLIGHT-ABORT no $PKG"; return 9; }
  for f in "$TOOLS/probe.py" "$TOOLS/turn2.py" "$TOOLS/check-prod-env.py" "$TOOLS/prod.env" "$BOX/build_patches.sh"; do
    [ -f "$f" ] || { log "PREFLIGHT-ABORT no $f"; return 9; }
  done
  docker image inspect "$CUDA_IMG" > /dev/null 2>&1 || { log "PREFLIGHT-ABORT $CUDA_IMG absent"; return 9; }
  docker image inspect "$PROD_IMAGE" > /dev/null 2>&1 || { log "PREFLIGHT-ABORT production image absent"; return 9; }
  n=$(docker ps --format '{{.Names}}' | tr '\n' ' ')
  for c in $n; do
    [ "$c" = "$CN" ] || { log "FOREIGN-CONTAINER $c is running: this window will not touch it"; return 9; }
  done
  id=$(docker inspect "$CN" --format '{{.Image}}' 2>/dev/null || true)
  if [ -n "$id" ] && [ "$id" = "$PROD_ID" ] && [ "$(healthcode "$URL")" = 200 ]; then
    log "PREFLIGHT production up and pinned $id /health 200"
  elif [ -z "$id" ] && [ -z "$n" ]; then
    log "PREFLIGHT-NOTE production is not running and nothing else is: this window restores it on the way out"
  else
    log "PREFLIGHT-ABORT production container image \"${id:-absent}\" /health $(healthcode "$URL") is not the pinned $PROD_ID"
    return 9
  fi
  startlock_free || { log "PREFLIGHT-ABORT start.lock is held"; return 9; }
  [ "$(freegib)" -ge 45 ] || { log "PREFLIGHT-ABORT home free $(freegib) GiB"; return 9; }
  [ "$(memav)" -ge 20 ] || { log "PREFLIGHT-ABORT MemAvailable $(memav) GiB with production still up"; return 9; }
  load=$(cut -d' ' -f1 /proc/loadavg)
  awk -v l="$load" 'BEGIN{exit !(l < 16)}' || { log "PREFLIGHT-ABORT load $load"; return 9; }
  log "PREFLIGHT host $(hostname) kernel $(uname -r) gpu [$(gpu)] load $load disk $(freegib) GiB mem $(memav) GiB"
  log "PREFLIGHT script $(sha256sum "$SELF" | cut -d' ' -f1) dev.env $(sha256sum "$DEV" | cut -d' ' -f1)"
  if docker inspect "$CN" > "$OUT/prod-inspect-before.json" 2>/dev/null; then
    python3 "$TOOLS/check-prod-env.py" --prod "$TOOLS/prod.env" --inspect "$OUT/prod-inspect-before.json" \
      > "$OUT/prod-env-before.txt" 2>&1 || true
    log "PROD-ENV before: $(tr '\n' ' ' < "$OUT/prod-env-before.txt" | cut -c1-400)"
  fi
  mark PREFLIGHT-OK
  return 0
}

prepare_tree() {
  local m files m2
  rm -rf "$BASE" "$TREE" "$NEWSRC" "$SRV"
  mkdir -p "$BASE" "$NEWSRC" "$SRV"
  git init -q -b main "$BASE" || { log "TREE-ABORT git init"; return 1; }
  git -C "$BASE" remote add origin https://github.com/ashhart/TensorFold.git || return 1
  git -C "$BASE" fetch -q --depth 1 origin "$BASE_REF" || { log "TREE-ABORT fetch $BASE_REF"; return 1; }
  git -C "$BASE" checkout -q --detach FETCH_HEAD || { log "TREE-ABORT checkout"; return 1; }
  log "BASE $(git -C "$BASE" rev-parse HEAD) $(git -C "$BASE" status --porcelain | wc -l) changes"
  cp -a "$BASE" "$TREE" || { log "TREE-ABORT copy"; return 1; }
  ( cd "$TREE" && bash "$PKG/apply.sh" --check . ) > "$OUT/apply-check.log" 2>&1 || { log "TREE-ABORT apply --check: $(tail -2 "$OUT/apply-check.log" | tr '\n' ' ')"; return 1; }
  log "TREE $(cat "$OUT/apply-check.log")"
  ( cd "$TREE" && bash "$PKG/apply.sh" . ) > "$OUT/apply.log" 2>&1 || { log "TREE-ABORT apply: $(tail -2 "$OUT/apply.log" | tr '\n' ' ')"; return 1; }
  log "TREE $(cat "$OUT/apply.log")"
  log "TREE-HEAD $(git -C "$TREE" rev-parse HEAD) changes $(git -C "$TREE" status --porcelain | wc -l)"
  m=$(tree_manifest "$TREE"); files=$(tree_files "$TREE")
  log "TREE-MANIFEST $m files $files want $WANT_MANIFEST $([ "$m" = "$WANT_MANIFEST" ] && echo EQUAL || echo MISMATCH)"
  if [ "$m" != "$WANT_MANIFEST" ]; then
    m2=$( ( cd "$TREE" && find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum ) | sha256sum | cut -d' ' -f1 )
    log "TREE-MANIFEST-ALT with .git $m2"
    [ "$m2" = "$WANT_MANIFEST" ] || { log "TREE-ABORT manifest is not the composition's"; return 1; }
  fi
  mark TREE-OK
}

serve_base() {
  # A UNIQUE ref name, because BuildKit keys a RUN layer by its command string: the recipe's fetch line names only the
  # repo and the ref, so a ref an earlier lane used (refs/heads/main, Int4Step5Dev) is served from that build's cache
  # and the patches then apply to the WRONG tree (measured 2026-11-24: 0001 failed on five files at 0 s). The forced
  # add keeps the files the repo's .gitignore names but git tracks (719 receipts), so the served tree is the base's.
  REF="r5dev40-$(date +%s)"
  tar -C "$BASE" --exclude=.git -cf - . | tar -C "$NEWSRC" -xf - || { log "BASE-ABORT extract"; return 1; }
  git -C "$NEWSRC" init -q -b main || return 1
  git -C "$NEWSRC" add -A -f || return 1
  git -C "$NEWSRC" -c user.name=base -c user.email=base@local -c commit.gpgsign=false commit -qm "TensorFold $BASE_REF tree" || return 1
  git -C "$NEWSRC" branch -f "$REF" HEAD || return 1
  log "BASE-TREE $(git -C "$NEWSRC" ls-tree -r HEAD | wc -l) entries served (base $(git -C "$BASE" ls-tree -r HEAD | wc -l), ref refs/heads/$REF $(git -C "$NEWSRC" rev-parse HEAD))"
  git clone -q --bare "$NEWSRC" "$SRV/base.git" || { log "BASE-ABORT bare clone"; return 1; }
  pkill -f "git daemon.*--port=9419" > /dev/null 2>&1 || true
  setsid nohup git daemon --reuseaddr --export-all --base-path="$SRV" --port=9419 --listen=0.0.0.0 "$SRV" \
    > "$OUT/gitd.log" 2>&1 < /dev/null &
  sleep 1
  git ls-remote "git://192.168.99.16:9419/base.git" "refs/heads/$REF" >> "$OUT/gitd.log" 2>&1 || { log "BASE-ABORT ls-remote"; return 1; }
  log "GITD ref refs/heads/$REF $(tail -1 "$OUT/gitd.log" | cut -c1-160)"
  mark BASE-SERVED
}

build_image() {
  local t0 wall rc
  [ -n "${REF:-}" ] || { log "BUILD-ABORT no served ref"; return 1; }
  t0=$(date +%s)
  ( cd "$HOME/work/target" && bash "$BOX/build_patches.sh" r5dev40 "git://192.168.99.16:9419/base.git" "refs/heads/$REF" "$PKG" ) \
    > "$OUT/build-image.log" 2>&1
  rc=$?
  wall=$(( $(date +%s) - t0 ))
  if [ "$rc" != 0 ] || ! grep -aq '^BUILT ' "$OUT/build-image.log"; then
    log "BUILD-FAILED rc $rc wall ${wall}s :: $(grep -aE '^error|error:|ERROR' "$OUT/build-image.log" | head -3 | tr '\n' ' ' | cut -c1-400)"
    mark BUILD-FAILED
    return 1
  fi
  log "BUILD $(grep -a '^BUILT ' "$OUT/build-image.log") wall ${wall}s"
  bash "$HOME/work/lanes/fp4port/relabel.sh" tensorfold-qwen38:r5dev40 embedded > "$OUT/relabel.log" 2>&1 \
    || { log "BUILD-ABORT relabel: $(tail -1 "$OUT/relabel.log")"; return 1; }
  cat "$OUT/relabel.log" >> "$OUT/build-image.log"
  IMAGE_ID=$(docker image inspect tensorfold-qwen38:r5dev40 --format '{{.Id}}')
  docker image inspect tensorfold-qwen38:r5dev40 \
    --format 'Created={{.Created}} kernels={{index .Config.Labels "tf.kernels"}} patches={{index .Config.Labels "tf.patches"}}' \
    >> "$OUT/build-image.log"
  echo "$IMAGE_ID $(grep -o 'wall [0-9]*s' <<< "wall ${wall}s")" > "$OUT/IMAGE"
  log "IMAGE $IMAGE_ID $(tail -1 "$OUT/build-image.log")"
  mark BUILT
}

run_contract() {
  local rc
  echo "gpu_before contract $(gpu)" > "$OUT/temp-contract.txt"
  log "GPU-TEMP contract $(gputemp) C"
  docker run --rm --gpus all --ipc=host --user "$(id -u):$(id -g)" -e HOME=/tmp \
    -v "$TREE:/tf" -v "$ZC:/zc" -w /tf "$CUDA_IMG" \
    /opt/zig/zig build --summary all --cache-dir /zc/local int4-contract -Dnvcc=/usr/local/cuda/bin/nvcc \
    > "$OUT/int4-contract.log" 2>&1
  rc=$?
  echo "gpu_after contract $(gpu)" >> "$OUT/temp-contract.txt"
  grep -a '^SUMMARY int4\|^CONTROL \|^PASS int4\|^FAIL \|^KNOWN ' "$OUT/int4-contract.log" > "$OUT/int4-contract-lines.txt" 2>/dev/null || true
  log "CONTRACT rc $rc $(tr '\n' '|' < "$OUT/int4-contract-lines.txt" | cut -c1-800)"
  if [ "$rc" = 0 ] && grep -q '^SUMMARY int4: .* 0 fail, .* 0 missed' "$OUT/int4-contract-lines.txt"; then
    mark CONTRACT-OK
    return 0
  fi
  log "CONTRACT-FAILED: $(grep -aE 'error:|expected|FAIL' "$OUT/int4-contract.log" | head -3 | tr '\n' ' ' | cut -c1-400)"
  mark CONTRACT-FAILED
  return 1
}

boot_dev() {
  local rc=0 i code
  stop_cn
  startlock_free || { log "START-LOCK held before the dev boot"; return 9; }
  log "GPU-TEMP boot $(gputemp) C"
  (
    set -a
    # shellcheck disable=SC1090
    . "$DEV"
    set +a
    cd "$HOME" || exit 9
    timeout 2400 env LOCK_HOLDER=0 PARALLEL=8 CONTEXT=262144 WARM_TURNS=0 IMAGE="$IMG" \
      "$HOME/qwen6-start.sh" </dev/null
  ) > "$OUT/boot.log" 2>&1 || rc=$?
  if grep -q "another ./start.sh is already running" "$OUT/boot.log" 2>/dev/null; then
    log "BOOT-START-LOCK from start.sh"; return 9
  fi
  docker logs "$CN" > "$OUT/server.log" 2>&1 || true
  if [ "$rc" != 0 ]; then
    {
      grep -aE "tensorfold: |rejects these arguments|error\.|not allowed|refused|needs .* GiB" "$OUT/boot.log" 2>/dev/null
      grep -aE "tensorfold: |error\.|refused|needs .* GiB" "$OUT/server.log" 2>/dev/null
    } | sort -u | head -10 > "$OUT/refusal.txt"
    log "BOOT-REFUSED rc $rc wall n/a :: $(head -3 "$OUT/refusal.txt" | tr '\n' ' ' | cut -c1-600)"
    mark BOOT-REFUSED
    return 1
  fi
  for i in $(seq 1 120); do
    code=$(healthcode "$URL")
    [ "$code" = 200 ] && break
    sleep 2
  done
  if [ "$code" != 200 ]; then
    log "BOOT-HEALTH-BAD /health $code"; mark BOOT-REFUSED; return 1
  fi
  docker inspect "$CN" --format '{{range .Config.Env}}{{println .}}{{end}}' 2>/dev/null \
    | grep -E '^(TF_|TENSORFOLD_)[A-Z0-9_]*=' | sort > "$OUT/served-env.txt" || true
  docker inspect "$CN" --format '{{json .Config.Cmd}}' > "$OUT/served-cmd.json" 2>/dev/null || true
  docker inspect "$CN" --format '{{.Config.Image}} {{.Image}}' > "$OUT/served-image.txt" 2>/dev/null || true
  docker inspect "$CN" --format '{{range .Mounts}}{{.Source}} -> {{.Destination}}{{println}}{{end}}' > "$OUT/served-mounts.txt" 2>/dev/null || true
  curl -s --max-time 10 "$URL/v1/models" > "$OUT/models.json" 2>/dev/null || true
  curl -s --max-time 10 "$URL/health" > "$OUT/health.json" 2>/dev/null || true
  grep -a "at once ·" "$OUT/boot.log" | head -1 > "$OUT/banner.txt" || true
  grep -a "Server answered after" "$OUT/boot.log" | head -1 > "$OUT/loaded.txt" || true
  grep -a "streams at once, the engine's own" "$OUT/server.log" | tail -1 > "$OUT/plan.txt" || true
  grep -a "KV page groups" "$OUT/server.log" | tail -1 > "$OUT/pagegroups.txt" || true
  grep -a "window self-check:" "$OUT/server.log" | tail -1 > "$OUT/selfcheck.txt" || true
  if [ ! -s "$OUT/banner.txt" ] || [ ! -s "$OUT/plan.txt" ] || [ ! -s "$OUT/selfcheck.txt" ]; then
    log "BOOT-GATE-MISSING banner=$([ -s "$OUT/banner.txt" ] && echo ok || echo no) plan=$([ -s "$OUT/plan.txt" ] && echo ok || echo no) selfcheck=$([ -s "$OUT/selfcheck.txt" ] && echo ok || echo no)"
    return 1
  fi
  log "BOOT-OK rc $rc health $code image $(cat "$OUT/served-image.txt") $(gputemp) C"
  log "BANNER $(cat "$OUT/banner.txt")"
  log "LOADED $(cat "$OUT/loaded.txt")"
  log "PLAN $(cat "$OUT/plan.txt")"
  log "PAGEGROUPS $(cat "$OUT/pagegroups.txt")"
  log "SELF-CHECK $(cat "$OUT/selfcheck.txt")"
  mark BOOT-OK
}

cells() {
  local model code line rc
  model=$(python3 -c 'import json;print(json.load(open("'"$OUT"'/models.json"))["data"][0]["id"])' 2>/dev/null || true)
  if [ -z "$model" ] || [ "$model" = None ]; then log "CELLS-ABORT no served model id"; return 1; fi
  log "MODEL $model"
  grep -a '^TF_FLASHNEXT_MTP_WEIGHTS=\|^TENSORFOLD_CUDA_KERNELS=\|^TF_FLASHNEXT_KV_PAGES=\|^TF_FLASHNEXT_SHARED_DRAFTS=\|^TF_FLASHNEXT_DRAFTS_GREEDY=\|^TF_FLASHNEXT_GREEDY_WIDE=\|^TF_FLASHNEXT_INT4_TILE=\|^TF_FLASHNEXT_HEAD_ROW_TILES=\|^TF_FLASHNEXT_INT4_PROMPT_GATE_UP=\|^TF_FLASHNEXT_INT4_PROMPT_DOWN=' "$OUT/served-env.txt" \
    > "$OUT/served-keys.txt" || true
  log "ENV $(tr '\n' '|' < "$OUT/served-keys.txt" | cut -c1-700)"
  grep -ao '"--prompt-cache-gib","[0-9]*"\|"--prompt-cache-disk","[^"]*"\|"--learn-gib","[0-9]*"\|"--learn-daily-gib","[0-9]*"\|"--learn-min-free-gib","[0-9]*"\|"--kv-cache","[^"]*"\|"--parallel","[0-9]*"\|"--context","[0-9]*"' "$OUT/served-cmd.json" \
    > "$OUT/served-cmd-keys.txt" 2>/dev/null || true
  log "CMD $(tr '\n' '|' < "$OUT/served-cmd-keys.txt")"

  # 1. the window self-check
  if grep -q 'window self-check: 1176 of 1176 rows byte-equal' "$OUT/selfcheck.txt"; then
    log "CELL self-check PASS $(cat "$OUT/selfcheck.txt")"
  else
    log "CELL self-check FAIL $(cat "$OUT/selfcheck.txt")"
  fi

  # 2. the exactness set
  log "GPU-TEMP exactness $(gputemp) C"
  python3 "$TOOLS/probe.py" "$URL" "$model" --output "$OUT/exactness.json" --tokens 64 > "$OUT/exactness.log" 2>&1
  rc=$?
  grep -a '^PROMPTS \|^RUN \|^LOAD \|^BG \|^CELL \|^EXACTNESS ' "$OUT/exactness.log" > "$OUT/exactness-lines.txt" 2>/dev/null || true
  while IFS= read -r line; do log "EXACT $line"; done < "$OUT/exactness-lines.txt"
  log "EXACTNESS rc $rc $(grep -a '^EXACTNESS ' "$OUT/exactness.log" | tail -1)"
  mark EXACTNESS-DONE

  # 3. /stats and its gate
  code=$(curl -s -o "$OUT/stats.json" -w '%{http_code}' --max-time 5 "$URL/stats")
  log "STATS http $code body $(head -c 200 "$OUT/stats.json" 2>/dev/null | tr '\n' ' ')"
  {
    grep -n "pub fn stats" -A2 "$TREE/zig/src/server/status_routes.zig" | head -3
    grep -n '"--dashboard"' "$TREE/zig/src/server/cli.zig" | head -1
    grep -n "start.sh restart" "$HOME/qwen6-start.sh"
  } > "$OUT/stats-gate.txt" 2>/dev/null || true
  log "STATS-GATE $(tr '\n' '|' < "$OUT/stats-gate.txt" | cut -c1-500)"

  # 4. the tier's budget as the engine prints it, then one 129k resume
  docker logs "$CN" > "$OUT/server-after-exactness.log" 2>&1 || true
  grep -a "prompt cache:" "$OUT/server-after-exactness.log" | tail -3 > "$OUT/tier-lines.txt" || true
  log "TIER-STORE $(tail -1 "$OUT/tier-lines.txt" 2>/dev/null | cut -c1-500)"
  du -sh "$HOME/.cache/tensorfold-qwen38/4144696f21e3" 2>/dev/null > "$OUT/kvcache-size.txt" || true
  log "KVCACHE-DIR $(cat "$OUT/kvcache-size.txt" 2>/dev/null) mounts [$(tr '\n' ' ' < "$OUT/served-mounts.txt")]"
  log "GPU-TEMP resume $(gputemp) C"
  python3 "$TOOLS/turn2.py" "$URL" "$model" --tokens 128000 --pressure 0 --reply 16 --seed 20261124 \
    --output "$OUT/turn2.json" > "$OUT/turn2.log" 2>&1
  rc=$?
  grep -a '^A1 \|^A2 \|^T2 \|^A3 \|^TURN2 ' "$OUT/turn2.log" > "$OUT/turn2-lines.txt" 2>/dev/null || true
  while IFS= read -r line; do log "RESUME $line"; done < "$OUT/turn2-lines.txt"
  log "RESUME rc $rc"
  docker logs "$CN" > "$OUT/server-after-turn2.log" 2>&1 || true
  grep -a "prompt cache:" "$OUT/server-after-turn2.log" | grep -a "12[0-9][0-9][0-9][0-9] tokens\|129[0-9][0-9][0-9] tokens" | tail -6 > "$OUT/tier-resume-lines.txt" || true
  grep -a "imprint:" "$OUT/server-after-turn2.log" | tail -8 > "$OUT/tier-imprint-lines.txt" || true
  while IFS= read -r line; do log "RESUME-CACHE $line"; done < "$OUT/tier-resume-lines.txt"
  while IFS= read -r line; do log "RESUME-DISK $line"; done < "$OUT/tier-imprint-lines.txt"
  if grep -aq "imprint: read" "$OUT/tier-imprint-lines.txt" 2>/dev/null; then
    log "RESUME-BASIS disk (an imprint read line is present)"
  else
    log "RESUME-BASIS ram (the resume reports cached tokens with no imprint read from disk)"
  fi
  grep -a "prompt cache:" "$OUT/server-after-turn2.log" | tail -1 > "$OUT/tier-store-final.txt" || true
  log "TIER-STORE-FINAL $(cat "$OUT/tier-store-final.txt" 2>/dev/null | cut -c1-500)"
  log "GPU-TEMP after-cells $(gputemp) C"
  curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$URL/health" > "$OUT/health-after-cells.txt" 2>/dev/null || true
  log "HEALTH-AFTER-CELLS $(cat "$OUT/health-after-cells.txt")"
}

finish() {
  local id entry
  id=$(docker image inspect tensorfold-qwen38:r5dev40 --format '{{.Id}}' 2>/dev/null || true)
  if [ -n "$id" ]; then
    entry=$(
      printf '\n## r5dev40 dev image (DevBootComp agent, %s)\n\n' "$(date +%Y-%m-%d)"
      printf -- '- Docker image `tensorfold-qwen38:r5dev40` (`%s`): the r5-dev composition (40 patches on TensorFold `%s`) built on\n' "$id" "$BASE_REF"
      printf -- '  this box by the recipe'"'"'s `build_patches.sh`, `tf.kernels=embedded` via `~/work/lanes/fp4port/relabel.sh`; boots as\n'
      printf -- '  the dev arm through `~/qwen6-start.sh` with the composition'"'"'s `dev.env`. Removal:\n'
      printf -- '  `docker rmi tensorfold-qwen38:r5dev40`.\n'
    )
    printf '%s\n' "$entry" > "$OUT/INVENTORY-entry.md"
    if [ -f "$HOME/INVENTORY.md" ] && ! grep -q 'r5dev40 dev image' "$HOME/INVENTORY.md"; then
      printf '%s\n' "$entry" >> "$HOME/INVENTORY.md"
      log "INVENTORY updated with r5dev40 $id"
    else
      log "INVENTORY already carries r5dev40 (or is absent)"
    fi
  fi
  tar -C "$BOX" -czf "$BOX/ev.tgz" --exclude=./ev.tgz --exclude=./base --exclude=./tree --exclude=./newsrc \
    --exclude=./srv --exclude=./zcache --exclude=./pkg ./out ./in ./tools ./driver.sh ./probe.py 2> "$OUT/pack.err" || true
  log "EVIDENCE ev.tgz $(sha256sum "$BOX/ev.tgz" | cut -d' ' -f1) bytes $(stat -c %s "$BOX/ev.tgz" 2>/dev/null) files $(tar -tzf "$BOX/ev.tgz" 2>/dev/null | wc -l)"
  mark RUN-DONE
}

run_window() {
  : > "$OUT/run.log"
  echo "LOCKED $(now) pid $$" > "$OUT/LOCKED"
  log "LOCKED $(now) host $(hostname) uptime $(uptime -s) nproc $(nproc) gpu [$(gpu)] disk $(freegib) GiB mem $(memav) GiB"
  log "DISK-BEFORE $(df -h "$HOME" | tail -1)"
  log "PROD-BEFORE image $(docker inspect -f '{{.Config.Image}}' "$CN" 2>/dev/null) id $(docker inspect -f '{{.Image}}' "$CN" 2>/dev/null) health $(healthcode "$URL")"
  preflight || { echo "ABORT preflight $(now)" > "$OUT/ABORT"; return 9; }

  TOUCHED=1
  STOPPED_PROD=1
  stop_cn
  log "STOPPED production: :8888 $(healthcode "$URL"); containers [$(docker ps --format '{{.Names}}' | tr '\n' ' ')]; MemAvailable $(memav) GiB; $(free -g | awk '/^Mem:/{print "Mem used "$3" GiB, available "$7" GiB"}')"
  mark PROD-STOPPED

  prepare_tree || { echo "ABORT tree $(now)" > "$OUT/ABORT"; restore; finish; return 1; }
  serve_base || { echo "ABORT base $(now)" > "$OUT/ABORT"; restore; finish; return 1; }
  build_image || { echo "ABORT build $(now)" > "$OUT/ABORT"; restore; finish; return 1; }

  run_contract || log "CONTRACT not green; the boot proceeds and the receipt records it"
  boot_dev || { echo "ABORT boot $(now)" > "$OUT/ABORT"; stop_cn; restore; finish; return 1; }
  cells || log "CELLS did not complete; the receipt records what ran"

  stop_cn
  log "SERVE-DOWN $(now) containers [$(docker ps --format '{{.Names}}' | tr '\n' ' ')]"
  mark SERVE-DOWN
  restore
  finish
  log "WINDOW-END $(now)"
  return 0
}

run_window
rc=$?
log "driver exit $rc $(now)"
exit $rc
