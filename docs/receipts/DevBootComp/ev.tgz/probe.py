#!/usr/bin/env python3
"""probe.py BASE MODEL --output FILE [--tokens 64]

The r5dev40 window's exactness set on one live serve, greedy (temperature 0), thinking off, token ids and the
engine's own token_sha256 requested on every request:

  p200/p2k  a completion prompt with no `draft` field against the same with `"draft": false`
  conc      a fresh 2048-token completion sent while three other streams decode (four streams open), against the
            same prompt's solo reply sent after they finish; the LOAD line says how many were live at the send
  resume    a chat continued from its own history against one request carrying the same history, and a repeat

Every RUN line prints the reply's token ids count, the engine's token_sha256 (sha16), the self-sha over the ids,
the cached prompt tokens, the drafted/accepted counters and the rounds. A cell is EQ only when both requests
completed and their ids lists and shas are equal. Greedy replies only.
"""
import argparse
import hashlib
import json
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid

WORDS = ("lattice probe ferrule datum spindle gauge trellis offset stylus kinematic fixture wafer cosine baseline "
         "granite bearing encoder servo axis spline tolerance flatness runout bridge cipher mantle terrace "
         "harbour beacon ledger quarry anvil forge").split()


def filler(lines):
    out = []
    for i in range(lines):
        out.append(f"{i + 1}. " + " ".join(WORDS[(i * 7 + j * 3) % len(WORDS)] for j in range(12)))
    return "\n".join(out)


def post_json(url, body, timeout=1800):
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def tokenize(base, prompt):
    got = post_json(base + "/tokenize", {"prompt": prompt})
    ids = got.get("tokens")
    if not isinstance(ids, list) or not ids:
        raise SystemExit(f"tokenize: no tokens in {json.dumps(got)[:300]}")
    return [int(t) for t in ids]


def metrics(base):
    try:
        with urllib.request.urlopen(base + "/metrics", timeout=10) as r:
            text = r.read().decode("utf-8", "replace")
    except Exception:
        return {}
    out = {}
    for line in text.splitlines():
        if not line.startswith("tensorfold:"):
            continue
        parts = line[len("tensorfold:"):].strip().split()
        for key in ("decode_rounds_total", "mtp_drafted_total", "mtp_accepted_total", "prompt_tokens_total",
                    "generated_tokens_total"):
            for i, p in enumerate(parts):
                if p == key and i + 1 < len(parts):
                    try:
                        out[key] = float(parts[i + 1])
                    except ValueError:
                        pass
    return out


def ids_sha(ids):
    h = hashlib.sha256()
    for i, t in enumerate(ids):
        if i:
            h.update(b",")
        h.update(str(t).encode())
    return h.hexdigest()


def stream(base, model, body, tokens, timeout=1800, on_first=None):
    body = dict(body)
    body.setdefault("model", model)
    body.setdefault("max_tokens", tokens)
    body.setdefault("temperature", 0)
    body.setdefault("stream", True)
    body.setdefault("stream_options", {"include_usage": True})
    body.setdefault("chat_template_kwargs", {"enable_thinking": False})
    body.setdefault("return_token_ids", True)
    t0 = time.perf_counter()
    ids, text, shas, usage, err = [], [], {}, None, None
    route = "/v1/chat/completions" if "messages" in body else "/v1/completions"
    req = urllib.request.Request(base + route, data=json.dumps(body).encode(),
                                headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            for raw in r:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[len("data:"):].strip()
                if data == "[DONE]":
                    break
                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue
                if chunk.get("error"):
                    err = chunk["error"]
                    continue
                if on_first is not None and (chunk.get("tensorfold") or chunk.get("choices")):
                    on_first()
                    on_first = None
                tf = chunk.get("tensorfold")
                for block in (tf if isinstance(tf, list) else [tf]):
                    if not isinstance(block, dict):
                        continue
                    if block.get("token_ids"):
                        ids.extend(int(t) for t in block["token_ids"])
                    for k in ("token_sha256", "token_sha"):
                        if block.get(k):
                            shas[k] = block[k]
                for choice in chunk.get("choices") or []:
                    piece = (choice.get("delta") or {}).get("content")
                    if piece:
                        text.append(piece)
                if chunk.get("usage"):
                    usage = chunk["usage"]
    except urllib.error.HTTPError as exc:
        try:
            err = json.loads(exc.read().decode())
        except Exception:
            err = {"http": exc.code}
    except Exception as exc:
        err = {"transport": repr(exc)}
    joined = "".join(text)
    return {"ids": ids, "ids_sha256": ids_sha(ids) if ids else None, "text": joined, "sha": shas.get("token_sha256"),
            "usage": usage, "error": err, "seconds": round(time.perf_counter() - t0, 3),
            "cached": ((usage or {}).get("prompt_tokens_details") or {}).get("cached_tokens")}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("base")
    p.add_argument("model")
    p.add_argument("--output", required=True)
    p.add_argument("--tokens", type=int, default=64)
    args = p.parse_args()
    base, model = args.base.rstrip("/"), args.model
    salt = uuid.uuid4().hex[:12]
    ids200 = tokenize(base, f"Record {salt} of the probe set.\n" + filler(40))[:200]
    long = tokenize(base, f"Record {salt} of the probe set.\n" + filler(320))
    if len(long) < 2048:
        raise SystemExit(f"tokenize: {len(long)} ids, need 2048 for the 2k prompt")
    ids2k = long[:2048]
    ids_c = tokenize(base, f"Record {salt}-conc of the probe set.\n" + filler(400))[:2048]
    print(f"PROMPTS p200 {len(ids200)} ids p2k {len(ids2k)} ids conc {len(ids_c)} ids", flush=True)

    record = {"base": base, "model": model, "salt": salt,
              "prompts": {"p200": ids_sha(ids200), "p2k": ids_sha(ids2k), "conc": ids_sha(ids_c)},
              "runs": {}, "cells": {}}
    failures = []

    def one(name, body, tokens, collect=True):
        before = metrics(base)
        got = stream(base, model, body, tokens)
        after = metrics(base)
        got["counters"] = {k: after.get(k, 0) - before.get(k, 0)
                           for k in ("decode_rounds_total", "mtp_drafted_total", "mtp_accepted_total")}
        if got["ids"]:
            got["sha_matches_ids"] = got["sha"] == ids_sha(got["ids"])
        if collect:
            record["runs"][name] = got
        err = json.dumps(got["error"])[:200] if got["error"] else "-"
        print(f"RUN {name} ids {len(got['ids'])} sha {(got['sha'] or '-')[:16]} self {(got['ids_sha256'] or '-')[:8]} "
              f"cached {got['cached']} drafted {got['counters']['mtp_drafted_total']:.0f} "
              f"rounds {got['counters']['decode_rounds_total']:.0f} err {err} {got['seconds']}s", flush=True)
        return got

    def cell(name, a, b):
        ok = bool(a["ids"]) and a["ids"] == b["ids"] and bool(a["sha"]) and a["sha"] == b["sha"] and not a["error"] and not b["error"]
        record["cells"][name] = {"equal": ok, "sha": a["sha"], "ids": len(a["ids"]),
                                 "a_cached": a.get("cached"), "b_cached": b.get("cached"),
                                 "a_error": a["error"], "b_error": b["error"]}
        print(f"CELL {name} {'EQ' if ok else 'DIFFER'} sha {(a['sha'] or '-')[:16]} ids {len(a['ids'])} "
              f"cached {a.get('cached')}/{b.get('cached')}"
              + ("" if ok else f" first_diff {first_diff(a['ids'], b['ids'])} b_sha {(b['sha'] or '-')[:16]} "
                                f"err {json.dumps(a['error'])[:100]}/{json.dumps(b['error'])[:100]}"), flush=True)
        if not ok:
            failures.append(name)

    def completion(ids, draft_field=None, ignore_eos=False):
        body = {"prompt": ids, "max_tokens": args.tokens, "temperature": 0, "stream": True,
                "stream_options": {"include_usage": True}, "return_token_ids": True}
        if draft_field is not None:
            body["draft"] = draft_field
        if ignore_eos:
            body["ignore_eos"] = True
        return body

    # 1 and 2: the drafted field absent against "draft": false, at 200 and 2048 prompt tokens
    a200 = one("p200/drafted", completion(ids200), args.tokens)
    b200 = one("p200/plain", completion(ids200, draft_field=False), args.tokens)
    cell("p200 drafted-vs-plain", a200, b200)
    a2k = one("p2k/drafted", completion(ids2k), args.tokens)
    b2k = one("p2k/plain", completion(ids2k, draft_field=False), args.tokens)
    cell("p2k drafted-vs-plain", a2k, b2k)

    # 3: a FRESH 2048-token prompt sent while three other streams decode, then its solo twin once they finish
    bg_ids = [tokenize(base, f"Record {salt}-bg{i} of the probe set.\n" + filler(200))[16:] for i in range(3)]
    started = [threading.Event() for _ in range(3)]
    finished = [threading.Event() for _ in range(3)]
    bg = {}

    def run_bg(i):
        try:
            bg[i] = stream(base, model, completion(bg_ids[i], ignore_eos=True) | {"max_tokens": 2400},
                           2400, on_first=started[i].set)
        finally:
            finished[i].set()

    threads = [threading.Thread(target=run_bg, args=(i,), daemon=True) for i in range(3)]
    for t in threads:
        t.start()
    for e in started:
        e.wait(timeout=90)
    live = sum(1 for i in range(3) if started[i].is_set() and not finished[i].is_set())
    print(f"LOAD {live} of 3 background streams decoding at the concurrent send", flush=True)
    conc = one("conc/concurrent", completion(ids_c, draft_field=False), args.tokens)
    for t in threads:
        t.join(timeout=600)
    for i in range(3):
        r = bg.get(i) or {}
        print(f"BG {i} ids {len(r.get('ids') or [])} drafted {(r.get('counters') or {}).get('mtp_drafted_total')} "
              f"err {json.dumps(r.get('error'))[:80]} {r.get('seconds')}s", flush=True)
    record["runs"]["background"] = {str(i): {"ids": len((bg.get(i) or {}).get("ids") or []),
                                             "error": (bg.get(i) or {}).get("error"),
                                             "seconds": (bg.get(i) or {}).get("seconds")} for i in range(3)}
    record["load_live"] = live
    solo_c = one("conc/solo", completion(ids_c, draft_field=False), args.tokens)
    cell("conc concurrent-vs-solo", conc, solo_c)

    # 4: a chat continued from its own history against the same request served fresh, and a repeat for determinism
    sysmsg = {"role": "system", "content": f"session {salt}; answer from the record below only."}
    p1 = filler(120)
    q = "Reply with one short sentence: what did the record list above prove about the fixture?"
    turn1 = one("resume/turn1", {"messages": [sysmsg, {"role": "user", "content": p1}], "max_tokens": 32}, 32)
    history = [sysmsg, {"role": "user", "content": p1}, {"role": "assistant", "content": turn1["text"]},
               {"role": "user", "content": q}]
    fresh = one("resume/fresh", {"messages": history, "max_tokens": 48}, 48)
    resumed = one("resume/resumed", {"messages": history, "max_tokens": 48}, 48)
    resumed2 = one("resume/resumed2", {"messages": history, "max_tokens": 48}, 48)
    cell("resume resumed-vs-fresh", fresh, resumed)
    cell("resume repeats", resumed, resumed2)

    # informational: the explicit draft=True arm on a serve that drafts
    asked = one("draft/true", completion(ids200, draft_field=True), 8)
    record["draft_true"] = {"error": asked["error"], "ids": len(asked["ids"])}

    drafted = sum(r.get("counters", {}).get("mtp_drafted_total", 0) for r in record["runs"].values()
                  if isinstance(r, dict) and "counters" in r)
    sha_ok = all(r.get("sha_matches_ids", True) for r in record["runs"].values()
                 if isinstance(r, dict) and r.get("ids"))
    record["complete"] = not failures
    record["drafted_total"] = drafted
    record["sha_matches_ids"] = sha_ok
    with open(args.output, "w") as f:
        json.dump(record, f, indent=1, sort_keys=True, default=str)
    print(f"EXACTNESS {'PASS' if not failures else 'FAIL ' + ','.join(failures)} cells {len(record['cells'])} "
          f"drafted_total {drafted:.0f} sha_matches_ids {sha_ok} live_at_conc {live} "
          f"draft_true_error {json.dumps(record['draft_true']['error'])[:120] if record['draft_true']['error'] else '-'}",
          flush=True)
    return 0 if not failures else 1


def first_diff(a, b):
    for i, (x, y) in enumerate(zip(a, b)):
        if x != y:
            return i
    return None if len(a) == len(b) else min(len(a), len(b))


if __name__ == "__main__":
    sys.exit(main())
