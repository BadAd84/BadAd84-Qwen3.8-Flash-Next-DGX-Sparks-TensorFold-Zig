#!/usr/bin/env bash
# contract_window.sh - the composition's int4-contract suite on the verified built tree, in its own hold of
# ~/work/gpu.lock. The build window's first contract call failed rc 127 because `tensorfold-qwen38:zig-db28187` has no
# /opt/zig; this one mounts the box's own Zig 0.17.0 (`~/zigtools`) at /zigtools and runs the same `zig build
# int4-contract -Dnvcc=...` with the CUDA image's nvcc 13.3 (the box carries no host nvcc). Production is stopped
# inside the hold and restored by the EXIT trap; /health, the pinned image id and check-prod-env are the proof.
set -u
BOX=${CW_BOX:-$HOME/work/DevBootComp}
OUT=$BOX/out/contract2
TREE=$BOX/tree
ZC=$BOX/zcache
CUDA_IMG=tensorfold-qwen38:zig-db28187
PROD_IMAGE=tensorfold-qwen38:zmerge8-kfix-e5139fcd8c6101c7
PROD_ID=sha256:235211ea77ee4ed0e61c4c2e73746ed17eccfb6b9e7571eb0787802440f8a33f
CN=qwen38-flash-next-tf
URL=http://127.0.0.1:8888
RECIPE=${CW_RECIPE:-$HOME/qwen-zig}
TOOLS=$BOX/tools
LOCKF=${CW_LOCKF:-$HOME/work/gpu.lock}
LOG=$OUT/run.log
mkdir -p "$OUT"
log() { echo "$(date -Is) $*" >> "$LOG"; }
now() { date -Is; }
memav() { awk '/MemAvailable/{print int($2/1048576)}' /proc/meminfo; }
healthcode() { curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$1/health" 2>/dev/null; }
imgof() { docker inspect "$CN" --format '{{.Config.Image}} {{.Image}}' 2>/dev/null || true; }
gputemp() { nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader 2>/dev/null | tr -d ' '; }
startlock_free() { flock -n "$HOME/.local/state/qwen38-flash-next-tf/start.lock" true 2>/dev/null; }

RESTORED=0
TOUCHED=0
restore() {
  local i code=000 pimg="" rc=0
  if [ "$RESTORED" = 1 ]; then return 0; fi
  RESTORED=1
  log "RESTORE begin $(now)"
  ( cd "$RECIPE" && ./stop.sh ) >> "$LOG" 2>&1 || true
  for i in $(seq 1 60); do
    [ "$(docker inspect -f '{{.State.Running}}' "$CN" 2>/dev/null)" != true ] && break
    sleep 2
  done
  for i in $(seq 1 60); do startlock_free && break; sleep 2; done
  if ! startlock_free; then
    echo "start.lock is held by another ./start.sh: the production launcher was not run" > "$OUT/prod.out"
    log "PROD-START-LOCKED"
  else
    ( env -u IMAGE LOCK_HOLDER=0 IMAGE="$PROD_IMAGE" "$HOME/qwen6-start-prod.sh" </dev/null ) > "$OUT/prod.out" 2>&1 || rc=$?
  fi
  for i in $(seq 1 180); do code=$(healthcode "$URL"); [ "$code" = 200 ] && break; sleep 5; done
  pimg=$(imgof)
  log "RESTORE prod_rc $rc /health $code image ${pimg:-absent} $(now)"
  echo "prod /health $code (start rc $rc) image ${pimg:-absent} $(now)" > "$OUT/RESTORED"
  curl -s --max-time 10 "$URL/health" > "$OUT/health-restored.json" 2>/dev/null || true
  docker inspect "$CN" > "$OUT/prod-inspect-after.json" 2>/dev/null || true
  case "$pimg" in
    *"$PROD_IMAGE"*"$PROD_ID"*) log "PROD-IMAGE-OK $pimg" ;;
    *) log "PROD-IMAGE-BAD ${pimg:-absent}" ;;
  esac
  python3 "$TOOLS/check-prod-env.py" --prod "$TOOLS/prod.env" --inspect "$OUT/prod-inspect-after.json" \
    > "$OUT/prod-env-after.txt" 2>&1 || true
  log "PROD-ENV after: $(tr '\n' ' ' < "$OUT/prod-env-after.txt" 2>/dev/null | cut -c1-400)"
  grep -q '0 problem(s)$' "$OUT/prod-env-after.txt" 2>/dev/null && log "PROD-ENV-EQUAL" || log "PROD-ENV-BAD"
  log "RESTORE end $(now)"
}
on_exit() { local rc=$?; log "EXIT rc $rc $(now)"; [ "$TOUCHED" = 1 ] && restore; log "EXIT-DONE $(now)"; exit $rc; }
trap on_exit EXIT
trap 'exit 143' INT TERM

if [ "${CW_LOCKED:-0}" != 1 ]; then
  echo "QUEUED $(now) pid $$" >> "$LOG"
  exec flock -o -w 43200 "$LOCKF" env CW_LOCKED=1 CW_BOX="$BOX" bash "$0"
fi

echo "LOCKED $(now) pid $$" > "$OUT/LOCKED"
log "LOCKED $(now) host $(hostname) gpu [$(gputemp) C] mem $(memav) GiB"
[ -d "$TREE" ] || { log "ABORT no tree at $TREE"; echo "ABORT tree $(now)" > "$OUT/ABORT"; exit 1; }
[ -f "$HOME/zigtools/zig" ] || { log "ABORT no ~/zigtools/zig"; echo "ABORT zig $(now)" > "$OUT/ABORT"; exit 1; }
{
  ( cd "$TREE" && find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum ) | sha256sum | cut -d' ' -f1
} > "$OUT/tree-manifest.txt" 2>&1
log "TREE $(git -C "$TREE" rev-parse HEAD) manifest $(cat "$OUT/tree-manifest.txt")"
log "ZIG $(HOME=/tmp "$HOME/zigtools/zig" version 2>&1)"

TOUCHED=1
( cd "$RECIPE" && ./stop.sh ) >> "$LOG" 2>&1 || true
for i in $(seq 1 60); do
  [ "$(docker inspect -f '{{.State.Running}}' "$CN" 2>/dev/null)" != true ] && break
  sleep 2
done
log "STOPPED production: :8888 $(healthcode "$URL"); containers [$(docker ps --format '{{.Names}}' | tr '\n' ' ')]; MemAvailable $(memav) GiB"

log "GPU-TEMP contract $(gputemp) C"
t0=$(date +%s)
docker run --rm --gpus all --ipc=host --user "$(id -u):$(id -g)" -e HOME=/tmp \
  -v "$TREE:/tf" -v "$ZC:/zc" -v "$HOME/zigtools:/zigtools:ro" -w /tf "$CUDA_IMG" \
  /zigtools/zig build --summary all --cache-dir /zc/local int4-contract -Dnvcc=/usr/local/cuda/bin/nvcc \
  > "$OUT/int4-contract.log" 2>&1
rc=$?
wall=$(( $(date +%s) - t0 ))
grep -a '^SUMMARY int4\|^CONTROL \|^PASS int4\|^FAIL \|^KNOWN ' "$OUT/int4-contract.log" > "$OUT/lines.txt" 2>/dev/null || true
log "CONTRACT rc $rc wall ${wall}s gpu_after [$(gputemp) C]"
while IFS= read -r line; do log "CONTRACT $line"; done < "$OUT/lines.txt"
grep -a '^Build Summary' "$OUT/int4-contract.log" > "$OUT/build-summary.txt" 2>/dev/null || true
log "CONTRACT $(cat "$OUT/build-summary.txt" 2>/dev/null | cut -c1-200)"
restore
log "WINDOW-END $(now)"
exit $rc
